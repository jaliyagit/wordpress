Contributors: jaliyawp
Requires at least: 5.2
Requires PHP:      7.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html






You can find PHP file from jb-form folder 
Edit and Enjoy your Wordpress Development 
please Donate 5$ coffee if you like 