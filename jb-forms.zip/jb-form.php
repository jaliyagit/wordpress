
<?php
/**
 * Plugin Name:jb-forms
 *
 * @package           JB-Forms-Package
 * @author            Jaliya Bandara
 * @copyright         JB-Forms
 * @license           GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       jb-forms
 * Plugin URI:        https://wordpress.org/plugins/jb-forms
 * Description:       Basic HTML Form.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Jaliya Bandara
 * Author URI:         
 * Text Domain:       
 * License:           GPL v2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Update URI:        https://wordpress.org/plugins/jb-forms
 */

function JBForms_view() {

	 
	 
		$tableout='<form>
	
		
		<table width="200" >
  <tbody>
	  
	<tr>
      <td>ID</td>
      <td><input type="text" id="txtbx_id" name="txtbx_id" placeholder="IdentityCardNumberor SSN" ></td>
      <td>Name</td>
      <td><input type="text" id="txtbx_name" name="txtbx_name" placeholder="Name" > </td>
    </tr>
    <tr>
      <td>Address</td>
	  <td><input type="text" id="txtbx_address" name="txtbx_address" placeholder="Address" ></td>
		 <td>Age</td>
      <td><input type="text"  id="txtbx_age" name="txtbx_age" placeholder="Age" ></td>
	 
    </tr>
   
    <tr>
      <td>Telephone</td>
      <td><input type="text"  id="txtbx_tp" name="txtbx_tp" placeholder="Telephone" ></td>
      <td>Mobile</td>
	  <td><input type="text"  id="txtbx_mobile" name="txtbx_mobile" placeholder="Mobile" ></td>
    </tr>
	      <tr>
      <td></td>
      <td></td>
      <td><button type="button">Save</button></td>
	  <td> </td>
    </tr>
  </tbody>
</table>

		
	
	</form>';

      return $tableout;
    
}

add_shortcode('JBForms','JBForms_view');

 ?>